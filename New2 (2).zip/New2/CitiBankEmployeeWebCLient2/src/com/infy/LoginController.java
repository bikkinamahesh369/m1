package com.infy;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import org.apache.axis.AxisFault;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String showLoginPage() {
		return "login";
	}


	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String showLoginPage1() {
		return "login";
	}

	
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String handleUserLogin(ModelMap model, @RequestParam String name,
			@RequestParam String password) {

		if (!loginService.validateUser(name, password)) {
			model.put("errorMessage", "Invalid Credentials");
			return "login";
		}

		model.put("name", name);
		return "welcome";
	}
	
	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String showWelcomePage() {
		return "welcome";
	}
	
	
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String showAddPage(ModelMap model) throws MalformedURLException, RemoteException {
		  java.net.URL endpointURL = new java.net.URL("http://localhost:8080/CitibankEmployee/services/EmployeeService");
		org.apache.axis.client.Service service = new 	org.apache.axis.client.Service();
		EmployeeServiceSoapBindingStub stub = new EmployeeServiceSoapBindingStub(endpointURL,service);
		Employee e = new Employee();
		e.setName("mahesh");
		e.setRoll(673287);
	    String name=stub.add(e);
		
		model.put("name", name);
		
		return "addEmployee";
	}

	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public String showViewPage() {
		return "viewEmployees";
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String showDeletePage() {
		return "deleteEmployee";
	}

	
}
