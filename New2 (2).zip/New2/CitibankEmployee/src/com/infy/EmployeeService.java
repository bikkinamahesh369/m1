package com.infy;

public class EmployeeService {

	
	public String add(Employee e){
		return "add-success";
		
	}
	
	
	public String delete(Employee e){
		return "delete-success";
		
	}
	
	
	
	
	
}
