package com.infy;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import org.apache.axis.AxisFault;
import org.apache.axis.client.Service;

public class Test {

	public static void main(String[] args) throws MalformedURLException, RemoteException {
		// TODO Auto-generated method stub

		java.net.URL endpointURL = new java.net.URL("http://localhost:8080/CitibankEmployee/services/EmployeeService");
		org.apache.axis.client.Service service = new 	org.apache.axis.client.Service();
		EmployeeServiceSoapBindingStub stub = new EmployeeServiceSoapBindingStub(endpointURL,service);
		Employee e = new Employee();
		e.setName("mahesh");
		e.setRoll(673287);
	    String s=stub.delete(e);
		System.out.println(s);
		
		
	}

}
