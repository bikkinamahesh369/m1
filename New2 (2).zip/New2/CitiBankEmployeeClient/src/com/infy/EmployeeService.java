/**
 * EmployeeService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.infy;

public interface EmployeeService extends java.rmi.Remote {
    public java.lang.String add(com.infy.Employee e) throws java.rmi.RemoteException;
    public java.lang.String delete(com.infy.Employee e) throws java.rmi.RemoteException;
}
