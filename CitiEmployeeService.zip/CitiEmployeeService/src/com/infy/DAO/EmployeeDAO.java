package com.infy.DAO;

import java.util.List;

import com.infy.Model.Employee;

public interface EmployeeDAO {

public String addEmployee(Employee employee);
	
public String deleteEmployee(Employee employee);
	
public List<Employee> viewAllEmployees();
	
	
	
}
