package com.infy.DAO;

import java.util.List;

import org.apache.log4j.Logger;
import com.infy.Model.Employee;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class EmployeeDAOImpl extends HibernateDaoSupport implements EmployeeDAO {

	final static Logger logger = Logger.getLogger(EmployeeDAOImpl.class);
	
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		getHibernateTemplate().save(employee);
		 logger.debug("Hibernate - add- success");
		return "success";
	}

	@Override
	public String deleteEmployee(Employee employee) {
		// TODO Auto-generated method stub
		getHibernateTemplate().delete(employee);
		 logger.debug("Hibernate - delete - success");
		return "success";
	}

	@Override
	public List<Employee> viewAllEmployees() {
		// TODO Auto-generated method stub
		@SuppressWarnings("unchecked")
		List<Employee> list = getHibernateTemplate().find("from EmployeeTable");
		 logger.debug("Hibernate - viewAll - success");
		 return list;
		
}
}