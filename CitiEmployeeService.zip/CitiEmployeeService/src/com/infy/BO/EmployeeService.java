package com.infy.BO;

import java.util.List;

import com.infy.Model.Employee;

public interface EmployeeService {

	public String addEmployee(Employee employee);
	
	public String deleteEmployee(Employee employee);
	
	public List<Employee> viewAllEmployees();
	
}
