/**
 * 
 */
package com.infy.BO;

import java.util.List;

import org.apache.log4j.Logger;

import com.infy.DAO.EmployeeDAOImpl;
import com.infy.Model.Employee;

/**
 * @author mahesh
 *
 */

public class EmployeeServiceImpl implements EmployeeService {

	
	EmployeeDAOImpl employeeDAOImpl;
	
	
	final static Logger logger = Logger.getLogger(EmployeeServiceImpl.class);
	
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
	   
		String status= null;
		try {
			status=employeeDAOImpl.addEmployee(employee);
		  
		} catch (Exception e) {
			
			 logger.debug("This is error in addEmployee "+e.getMessage());
			status="failed";
			
		}
		return status;
		
	}

	@Override
	public String deleteEmployee(Employee employee) {
		// TODO Auto-generated method stub
		String status= null;
		try {
			status=employeeDAOImpl.deleteEmployee(employee);
		  
		} catch (Exception e) {
			
			 logger.debug("This is error in deleteEmployee "+e.getMessage());
			status="failed";
			
		}
		return status;
		
	}

	@Override
	public List<Employee> viewAllEmployees() {
		// TODO Auto-generated method stub
		List<Employee> allEmployees= null;
		try {
	allEmployees = employeeDAOImpl.viewAllEmployees();
		  
		} catch (Exception e) {
			
			 logger.debug("This is error viewAllEmployees"+e.getMessage());
			
		}
		return allEmployees;
		
	}

}
