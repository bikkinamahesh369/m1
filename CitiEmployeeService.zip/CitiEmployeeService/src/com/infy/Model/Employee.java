/**
 * 
 */
package com.infy.Model;

import javax.persistence.Column;
import javax.persistence.Entity;

/**
 * @author mahesh
 *
 */

@Entity
public class Employee {


	private String empName;
	private int empID;
	private int age;
	private String supplier;
	private String country;
    private String module;
    
    public Employee(){
       super();
    } 
    
	
  public Employee(String empName, int empID, int age, String supplier, String country, String module) {
		super();
		this.empName = empName;
		this.empID = empID;
		this.age = age;
		this.supplier = supplier;
		this.country = country;
		this.module = module;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	@Column( unique = true, nullable = false)
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getSupplier() {
		return supplier;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	
	
	
	
}
