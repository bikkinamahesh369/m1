package com.infy;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infy.BO.EmployeeServiceImpl;
import com.infy.Model.Employee;

public class TestApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
       Employee employee = new Employee("Mahesh", 673287, 18, "Infosys", "India", "CitiSearch");
   	ApplicationContext appContext = new ClassPathXmlApplicationContext("Spring.xml");

   	EmployeeServiceImpl empService= (EmployeeServiceImpl)appContext.getBean("EmployeeServiceImpl");
     empService.addEmployee(employee);
     empService.deleteEmployee(employee);
     empService.viewAllEmployees();
      
		
	}

}
